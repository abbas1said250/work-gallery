const $ = s => document.querySelector(s);
const loginPanel = $("#loginPanel"), galleryPanel = $("#galleryPanel");
let allMedia = [], currentFilter = "all", viewerIndex = 0;
async function api(url, options={}) {
  const res = await fetch(url, { credentials:"same-origin", ...options });
  const data = await res.json().catch(()=>({}));
  if (!res.ok) throw new Error(data.error || "تعذر إكمال الطلب.");
  return data;
}
function escapeHtml(s="") { return String(s).replace(/[&<>"']/g, c => ({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c])); }
function mediaUrl(item){ return `/media/${encodeURIComponent(item.id)}`; }
function dateText(ms){ try{return new Date(ms).toLocaleDateString("ar-IQ",{year:"numeric",month:"short",day:"numeric"});}catch{return "";} }
async function showGallery(){
  loginPanel.classList.add("hidden"); galleryPanel.classList.remove("hidden");
  allMedia = await api("/api/media"); $("#allCount").textContent = allMedia.length; renderGrid();
}
function renderGrid(){
  const items = allMedia.filter(x=>currentFilter==="all"||x.type===currentFilter);
  $("#mediaGrid").innerHTML = items.map(item=>`<article class="media-card" data-id="${escapeHtml(item.id)}">
    <div class="media-thumb">${item.type==="image"?`<img loading="lazy" src="${mediaUrl(item)}" alt="${escapeHtml(item.caption||item.name)}">`:`<video preload="metadata" src="${mediaUrl(item)}#t=0.1"></video><span class="play">▶</span>`}</div>
    <div class="media-meta"><strong>${escapeHtml(item.caption||item.name)}</strong><small>${item.type==="image"?"صورة":"فيديو"} · ${dateText(item.createdAt)}</small></div></article>`).join("");
  $("#emptyState").classList.toggle("hidden", allMedia.length!==0);
  $("#mediaGrid").classList.toggle("hidden", items.length===0);
  $("#mediaGrid").querySelectorAll(".media-card").forEach(card=>card.addEventListener("click",()=>openViewer(card.dataset.id)));
}
document.querySelectorAll(".filter").forEach(btn=>btn.addEventListener("click",()=>{
  document.querySelectorAll(".filter").forEach(b=>b.classList.remove("active"));btn.classList.add("active");currentFilter=btn.dataset.filter;renderGrid();
}));
$("#loginForm").addEventListener("submit",async e=>{
  e.preventDefault();$("#loginError").textContent="";
  try{await api("/api/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({code:$("#code").value})});await showGallery();}
  catch(err){$("#loginError").textContent=err.message;}
});
$("#logoutBtn").addEventListener("click",async()=>{await api("/api/logout",{method:"POST"});location.reload();});
function openViewer(id){viewerIndex=allMedia.findIndex(x=>x.id===id);showViewer();}
function showViewer(){
  const item=allMedia[viewerIndex];if(!item)return;
  $("#viewerContent").innerHTML=item.type==="image"?`<img src="${mediaUrl(item)}" alt="${escapeHtml(item.caption||item.name)}">`:`<video src="${mediaUrl(item)}" controls autoplay playsinline></video>`;
  $("#viewerCaption").textContent=item.caption||item.name;$("#viewer").classList.remove("hidden");
}
function closeViewer(){$("#viewer").classList.add("hidden");$("#viewerContent").innerHTML="";}
$("#closeViewer").addEventListener("click",closeViewer);
$("#prevViewer").addEventListener("click",()=>{viewerIndex=(viewerIndex-1+allMedia.length)%allMedia.length;showViewer();});
$("#nextViewer").addEventListener("click",()=>{viewerIndex=(viewerIndex+1)%allMedia.length;showViewer();});
document.addEventListener("keydown",e=>{if(e.key==="Escape")closeViewer();if(e.key==="ArrowLeft"&&!$("#viewer").classList.contains("hidden"))$("#nextViewer").click();if(e.key==="ArrowRight"&&!$("#viewer").classList.contains("hidden"))$("#prevViewer").click();});
(async()=>{try{const s=await api("/api/session");if(s.viewer)await showGallery();}catch{}})();