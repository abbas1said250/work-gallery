const $ = s => document.querySelector(s);
async function api(url, options={}) {
 const res=await fetch(url,{credentials:"same-origin",...options});
 const data=await res.json().catch(()=>({}));
 if(!res.ok)throw new Error(data.error||"تعذر إكمال الطلب.");
 return data;
}
function esc(s=""){return String(s).replace(/[&<>"']/g,c=>({"&":"&amp;","<":"&lt;",">":"&gt;",'"':"&quot;","'":"&#39;"}[c]));}
function fileUrl(item){return `/media/${encodeURIComponent(item.id)}`;}
function showAdmin(){ $("#adminLogin").classList.add("hidden");$("#adminPanel").classList.remove("hidden");loadItems();}
$("#adminLoginForm").addEventListener("submit",async e=>{
 e.preventDefault();$("#adminLoginError").textContent="";
 try{await api("/api/admin/login",{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({password:$("#password").value})});showAdmin();}
 catch(err){$("#adminLoginError").textContent=err.message;}
});
async function loadItems(){
 try{
  const items=await api("/api/admin/media");$("#adminCount").textContent=`${items.length} ملف`;
  $("#adminMediaList").innerHTML=items.map(x=>`<div class="admin-row" data-id="${esc(x.id)}">
   ${x.type==="image"?`<img src="${fileUrl(x)}" alt="">`:`<video src="${fileUrl(x)}#t=0.1"></video>`}
   <div class="row-info"><strong>${esc(x.caption||x.name)}</strong><small>${x.type==="image"?"صورة":"فيديو"} · ${esc(x.name)}</small></div>
   <button class="delete-btn" data-delete="${esc(x.id)}">حذف الملف</button></div>`).join("")||'<p class="muted">ماكو ملفات مضافة لحد الآن.</p>';
  document.querySelectorAll("[data-delete]").forEach(b=>b.addEventListener("click",async()=>{
   if(!confirm("متأكد تريد حذف هذا الملف نهائياً؟"))return;
   try{await api(`/api/admin/media/${encodeURIComponent(b.dataset.delete)}`,{method:"DELETE"});loadItems();}
   catch(err){alert(err.message);}
  }));
 }catch(err){$("#adminMediaList").textContent=err.message;}
}
$("#uploadForm").addEventListener("submit",async e=>{
 e.preventDefault();const msg=$("#uploadMessage"),file=$("#mediaFile").files[0];msg.textContent="";
 if(!file)return;
 if(file.size>150*1024*1024){msg.textContent="حجم الملف أكبر من 150 ميغابايت.";return;}
 const fd=new FormData();fd.append("media",file);fd.append("caption",$("#caption").value);
 msg.textContent="جارٍ رفع الملف، انتظر...";
 try{await api("/api/admin/upload",{method:"POST",body:fd});msg.textContent="تم رفع الملف بنجاح.";$("#uploadForm").reset();loadItems();}
 catch(err){msg.textContent=err.message;}
});
$("#adminLogout").addEventListener("click",async()=>{try{await api("/api/admin/logout",{method:"POST"});}finally{location.reload();}});
(async()=>{try{const s=await api("/api/session");if(s.admin)showAdmin();}catch{}})();