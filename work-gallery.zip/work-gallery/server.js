require("dotenv").config();
const express = require("express");
const session = require("express-session");
const multer = require("multer");
const path = require("path");
const fs = require("fs");

const app = express();
const PORT = Number(process.env.PORT || 3000);
const VIEW_CODE = process.env.VIEW_CODE;
const ADMIN_PASSWORD = process.env.ADMIN_PASSWORD;
const SESSION_SECRET = process.env.SESSION_SECRET;

if (!VIEW_CODE || !ADMIN_PASSWORD || !SESSION_SECRET ||
    VIEW_CODE.startsWith("CHANGE-ME") || ADMIN_PASSWORD.startsWith("CHANGE-ME") ||
    SESSION_SECRET.startsWith("replace-this")) {
  console.error("أكمل إعدادات .env وغيّر جميع القيم الافتراضية قبل التشغيل.");
  process.exit(1);
}

const ROOT = __dirname;
const UPLOAD_DIR = path.join(ROOT, "uploads");
const DATA_DIR = path.join(ROOT, "data");
const DB_FILE = path.join(DATA_DIR, "media.json");
fs.mkdirSync(UPLOAD_DIR, { recursive: true });
fs.mkdirSync(DATA_DIR, { recursive: true });
if (!fs.existsSync(DB_FILE)) fs.writeFileSync(DB_FILE, "[]", "utf8");

app.use(express.urlencoded({ extended: false, limit: "20kb" }));
app.use(express.json({ limit: "20kb" }));
app.use(session({
  name: "work_gallery_session",
  secret: SESSION_SECRET,
  resave: false,
  saveUninitialized: false,
  cookie: {
    httpOnly: true,
    sameSite: "lax",
    secure: process.env.NODE_ENV === "production",
    maxAge: 8 * 60 * 60 * 1000
  }
}));

function readMedia() {
  try { return JSON.parse(fs.readFileSync(DB_FILE, "utf8")); }
  catch { return []; }
}
function writeMedia(items) {
  fs.writeFileSync(DB_FILE, JSON.stringify(items, null, 2), "utf8");
}
function requireViewer(req, res, next) {
  if (req.session && (req.session.viewer || req.session.admin)) return next();
  if (req.path.startsWith("/api/")) return res.status(401).json({ error: "يلزم إدخال كود الدخول أولاً." });
  return res.redirect("/");
}
function requireAdmin(req, res, next) {
  if (req.session && req.session.admin) return next();
  if (req.path.startsWith("/api/")) return res.status(401).json({ error: "يلزم تسجيل دخول الإدارة." });
  return res.redirect("/admin");
}

const storage = multer.diskStorage({
  destination: (_req, _file, cb) => cb(null, UPLOAD_DIR),
  filename: (_req, file, cb) => {
    const ext = path.extname(file.originalname).toLowerCase();
    cb(null, `${Date.now()}-${Math.random().toString(36).slice(2, 10)}${ext}`);
  }
});
const upload = multer({
  storage,
  limits: { fileSize: 150 * 1024 * 1024, files: 1 },
  fileFilter: (_req, file, cb) => {
    const allowed = /^(image\/(jpeg|png|webp|gif)|video\/(mp4|webm|ogg|quicktime))$/i;
    if (allowed.test(file.mimetype)) cb(null, true);
    else cb(new Error("الملفات المسموحة: صور JPG/PNG/WEBP/GIF وفيديو MP4/WEBM/OGG/MOV."));
  }
});

app.use(express.static(path.join(ROOT, "public"), { index: "index.html" }));

app.post("/api/login", (req, res) => {
  const code = String(req.body.code || "");
  if (code !== VIEW_CODE) return res.status(401).json({ error: "كود الدخول غير صحيح." });
  req.session.viewer = true;
  res.json({ ok: true });
});
app.post("/api/logout", (req, res) => {
  req.session.destroy(() => res.json({ ok: true }));
});
app.get("/api/media", requireViewer, (_req, res) => {
  const items = readMedia().sort((a, b) => b.createdAt - a.createdAt);
  res.json(items.map(({ id, name, type, caption, createdAt }) => ({ id, name, type, caption, createdAt })));
});
// الملفات نفسها لا تُعرض إلا بعد التحقق من جلسة الدخول
app.get("/media/:id", requireViewer, (req, res) => {
  const item = readMedia().find(x => x.id === req.params.id);
  if (!item) return res.status(404).send("الملف غير موجود.");
  const filePath = path.join(UPLOAD_DIR, item.filename);
  if (!fs.existsSync(filePath)) return res.status(404).send("الملف غير موجود.");
  res.setHeader("X-Content-Type-Options", "nosniff");
  res.sendFile(filePath);
});

app.post("/api/admin/login", (req, res) => {
  if (String(req.body.password || "") !== ADMIN_PASSWORD) {
    return res.status(401).json({ error: "كلمة مرور الإدارة غير صحيحة." });
  }
  req.session.admin = true;
  res.json({ ok: true });
});
app.post("/api/admin/logout", requireAdmin, (req, res) => {
  req.session.admin = false;
  res.json({ ok: true });
});
app.get("/api/admin/media", requireAdmin, (_req, res) => {
  res.json(readMedia().sort((a, b) => b.createdAt - a.createdAt));
});
app.post("/api/admin/upload", requireAdmin, upload.single("media"), (req, res) => {
  if (!req.file) return res.status(400).json({ error: "اختر صورة أو فيديو أولاً." });
  const caption = String(req.body.caption || "").trim().slice(0, 160);
  const item = {
    id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`,
    filename: req.file.filename,
    name: path.basename(req.file.originalname).slice(0, 180),
    type: req.file.mimetype.startsWith("video/") ? "video" : "image",
    caption,
    createdAt: Date.now()
  };
  const items = readMedia();
  items.push(item);
  writeMedia(items);
  res.json({ ok: true, item: { id: item.id, name: item.name, type: item.type, caption: item.caption } });
});
app.delete("/api/admin/media/:id", requireAdmin, (req, res) => {
  const items = readMedia();
  const item = items.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "العنصر غير موجود." });
  const fullPath = path.join(UPLOAD_DIR, item.filename);
  if (fs.existsSync(fullPath)) fs.unlinkSync(fullPath);
  writeMedia(items.filter(x => x.id !== item.id));
  res.json({ ok: true });
});
app.get("/api/session", (req, res) => res.json({
  viewer: !!(req.session && req.session.viewer),
  admin: !!(req.session && req.session.admin)
}));

app.use((err, _req, res, _next) => {
  console.error(err.message);
  const status = err instanceof multer.MulterError ? 400 : 400;
  res.status(status).json({ error: err.message || "حدث خطأ أثناء معالجة الطلب." });
});

app.listen(PORT, () => console.log(`Work Gallery running on http://localhost:${PORT}`));
